/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpackage.se2224.finalproject;

/**
 *
 * @author kaanb
 */
public class FilePaths {
    static String movies = "C:\\Users\\kaanb\\Documents\\NetBeansProjects\\SE2224.1907006037.FinalProject\\src\\main\\java\\mainpackage\\se2224\\finalproject\\Movies";
    static String stars = "C:\\Users\\kaanb\\Documents\\NetBeansProjects\\SE2224.1907006037.FinalProject\\src\\main\\java\\mainpackage\\se2224\\finalproject\\Stars";
    static String ratings = "C:\\Users\\kaanb\\Documents\\NetBeansProjects\\SE2224.1907006037.FinalProject\\src\\main\\java\\mainpackage\\se2224\\finalproject\\Ratings";
    static String users = "C:\\Users\\kaanb\\Documents\\NetBeansProjects\\SE2224.1907006037.FinalProject\\src\\main\\java\\mainpackage\\se2224\\finalproject\\Users";
}
