/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpackage.se2224.finalproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author kaanb
 */
public class Ratings {
    private int movieId;
    private String firstName;
    private String lastName;
    private String relation;
    private int rating;
    ErrorScreen errorScreen = new ErrorScreen();
    File ratingsFile = new File(FilePaths.ratings);
    File moviesFile = new File(FilePaths.movies);

    public Ratings(int movieId, String firstName, String lastName, String relation, int rating) {
        this.movieId = movieId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.relation = relation;
        this.rating = rating;
    }

    public int getMovieId() {
        return movieId;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public String getRelation() {
        return relation;
    }
    public int getRating() {
        return rating;
    }


    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setRelation(String relation) {
        this.relation = relation;
    }
    public void setRating(int rating) {
        this.rating = rating;
    }
  
    public String getRatingDetails(){
        String str = "";
        str += getMovieId() + " " + getFirstName() + " " + getLastName() + " " + getRelation() + " " + getRating() + " " + CurrentUser.currentLoggedInUserName;
        return str;
    } 

    public double getAvgRating(int movieId){
        int sum = 0;
        int occurence = 0;
        double average = 0;
        try {                            
            BufferedReader breader = new BufferedReader(new FileReader(ratingsFile));
            String line = null;
            while ((line = breader.readLine()) != null) {
                String[] ratingsInfo = line.split(" ");
                int textMovieId = Integer.parseInt(ratingsInfo[0]);
                if(textMovieId == movieId){
                    sum += Integer.parseInt(ratingsInfo[4]);
                    occurence++;
                }
            }
            breader.close();
        } catch (Exception e){
            errorScreen.sendError("An error occured while calculating movie average.");
        }
        if (occurence != 0) {
            average += (double) sum/occurence;
        } else if (occurence == 0){
            return 0;
        }
        return average;
}

    public void updateMovieAvgRating(int movieID){ 
        try {                            
            BufferedReader breader = new BufferedReader(new FileReader(moviesFile));
            StringBuffer stringBuffer = new StringBuffer();
            String line = null;
            String newLine = "";
            double newRating = getAvgRating(movieID);
            while ((line = breader.readLine()) != null) {
                String[] movieInfo = line.split(" ");
                int textMovieId = Integer.parseInt(movieInfo[0]);
                if(textMovieId == movieID){
                    movieInfo[8] = String.valueOf(newRating);
                    for (int i = 0; i < movieInfo.length; i++) {
                        newLine += movieInfo[i] + " ";
                    }
                    line = newLine;
                }
                stringBuffer.append(line);
                stringBuffer.append('\n');
            }
            stringBuffer.deleteCharAt(stringBuffer.length()-1);
            breader.close(); 

            FileOutputStream newWrittenLine = new FileOutputStream(moviesFile);
            newWrittenLine.write(stringBuffer.toString().getBytes());
            newWrittenLine.close();
        } catch (Exception e){
            errorScreen.sendError("An error occured while saving your movie.");
        }
    }

    public void enterRatingToFile(Ratings rating){
        try {
            BufferedWriter bwriter = new BufferedWriter(new FileWriter(ratingsFile, true));
            BufferedReader breader = new BufferedReader(new FileReader(ratingsFile));
            if(breader.readLine() != null){
                bwriter.append("\n" + rating.getRatingDetails());
            } else if(breader.readLine() == null){
                bwriter.append(rating.getRatingDetails());
            }
            
            bwriter.close();
            breader.close();
            errorScreen.sendNotification("Rating added successfuly.");
        } catch (Exception e){
            errorScreen.sendError("An error occured while saving a new rating.");
        }
        updateMovieAvgRating(rating.getMovieId());
    }
    
}
