/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpackage.se2224.finalproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author kaanb
 */
public class Stars {
    private int movieId;
    private String movieTitle;
    private int movieYear;
    private String firstName;
    private String lastName;
    ErrorScreen errorScreen = new ErrorScreen();
    File starsFile = new File(FilePaths.stars);

    public Stars(int movieId, String movieTitle, int movieYear, String firstName, String lastName) {
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.movieYear = movieYear;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int getMovieId() {
        return movieId;
    }
    public String getMovieTitle() {
        return movieTitle;
    }
    public int getMovieYear() {
        return movieYear;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }


    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setMovieId(int movieId) {
            this.movieId = movieId;
    }
    public void setMovieTitle(String movieTitle) {
            this.movieTitle = movieTitle;
    }
    public void setFirstName(String firstName) {
            this.firstName = firstName;
    }
    public void setMovieYear(int movieYear) {
            this.movieYear = movieYear;
    }

    public String getStarDetails(){
        String str = "";
        str += getMovieId() + " " + getFirstName() + " " + getLastName() + " " + getMovieTitle() + " " + getMovieYear();
        return str;
    }
 
    public void enterStarToFile(Stars star){
        try {
            BufferedWriter bwriter = new BufferedWriter(new FileWriter(starsFile, true));
            BufferedReader breader = new BufferedReader(new FileReader(starsFile));
            if(breader.readLine() != null){
                bwriter.append("\n" + star.getStarDetails());
            } else {
                bwriter.append(star.getStarDetails());
            }
            bwriter.close();
            breader.close();
            errorScreen.sendNotification("Star has been successfully registered.");
        } catch (Exception e){
            errorScreen.sendError("An error occured while saving the star.");
        }
    
}

}