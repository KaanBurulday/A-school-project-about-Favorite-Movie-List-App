/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package mainpackage.se2224.finalproject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author kaanb
 */
public class ListScreen extends javax.swing.JFrame {
    File usersFile = new File(FilePaths.users);
    File moviesFile = new File(FilePaths.movies);
    File starsFile = new File(FilePaths.stars);
    ErrorScreen errorScreen = new ErrorScreen();
    /**
     * Creates new form ListScreen
     */
    public void getUserList(){
        try {
            movieListTextArea.setText(null);
            BufferedReader breader = new BufferedReader(new FileReader(usersFile));
            String line = null;
            while ((line = breader.readLine()) != null){
                movieListTextArea.append(line + "\n");
            }
            breader.close();
        } catch (IOException e) {
            errorScreen.sendError("An error occured while looking at users file.");
        }
    }
    
    public void setFrameTitle(String str){
        moviesListLabel.setText(str);
    }

    public void getMoviesList(){
        try {
            movieListTextArea.setText(null);
            BufferedReader breader = new BufferedReader(new FileReader(moviesFile));
            String line = null;
            while ((line = breader.readLine()) != null){
                line = line.replace("-", " ");
                movieListTextArea.append(line + "\n");
            }
            breader.close();
        } catch (IOException e) {
            errorScreen.sendError("An error occured while looking at movies file.");
        }
    }

    public void getMoviesListWithSelectedGenre(String str, double rating){
        try {
            movieListTextArea.setText(null);
            moviesListLabel.setText("Movie List");
            BufferedReader breader = new BufferedReader(new FileReader(moviesFile));
            String line = null;
            while ((line = breader.readLine()) != null){
                String[] movieInfo = line.split(" ");
                double movieRating = Double.parseDouble(movieInfo[8]);
                if ((movieInfo[3].equals(str)) && (movieRating == rating)){
                    line = line.replace("-", " ");
                    movieListTextArea.append(line + "\n");
                }
            }
            breader.close();
        } catch (IOException e) {
            errorScreen.sendError("An error occured while looking at movies file.");
        }
    }

    public void showMoviesOfaStar(String firstName, String lastName){
        int starMovieId = -1;
        try {
            BufferedReader starReader = new BufferedReader(new FileReader(starsFile));
            String starLine = null;
            while ((starLine = starReader.readLine()) != null){
                String[] starInfo = starLine.split(" ");
                if((firstName.toLowerCase().equals(starInfo[1].toLowerCase())) && (lastName.toLowerCase().equals(starInfo[2].toLowerCase()))){
                    starMovieId = Integer.parseInt(starInfo[0]);
                    if (starMovieId != -1){
                        String movie = getMovieDetailsById(starMovieId).replace("-", " ");
                        appendLine(movie);
                    }
                }
            }
        } catch (Exception e){
            errorScreen.sendError("An error occured while parsing movie ID.");
            this.dispose();
        }
        if (starMovieId == -1){
            errorScreen.sendError("An error occured while parsing movie ID.");
            this.dispose();
        }
    }

    public String getMovieDetailsById(int movieId){
        String str = "";
        try {
            BufferedReader breader = new BufferedReader(new FileReader(moviesFile));
            String line = null;
            while ((line = breader.readLine()) != null){
                String[] movieInfo = line.split(" ");
                int textMovieId = Integer.parseInt(movieInfo[0]);
                if(movieId == textMovieId){
                    str += line;
                }
            }
        } catch (Exception e){
            errorScreen.sendError("An error occured while parsing movie ID.");
        }
        return str;
    }

    public void getStarsList(){
        try {
            movieListTextArea.setText(null);
            BufferedReader breader = new BufferedReader(new FileReader(starsFile));
            String line = null;
            while ((line = breader.readLine()) != null){
                line = line.replace("-", " ");
                movieListTextArea.append(line + "\n");
            }
            breader.close();
        } catch (IOException e) {
            errorScreen.sendError("An error occured while looking at stars file.");
        }
    }

    public void appendLine(String line){
        movieListTextArea.append(line + "\n");
    }

    public ListScreen() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        exitButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        movieListTextArea = new javax.swing.JTextArea();
        moviesListLabel = new javax.swing.JLabel();
        refreshButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("EXIT");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        movieListTextArea.setEditable(false);
        movieListTextArea.setColumns(20);
        movieListTextArea.setFont(new java.awt.Font("Monospaced", 2, 14)); // NOI18N
        movieListTextArea.setLineWrap(true);
        movieListTextArea.setRows(5);
        jScrollPane1.setViewportView(movieListTextArea);

        moviesListLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        moviesListLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        moviesListLabel.setText("Movies List");

        refreshButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        refreshButton.setText("Refresh List");
        refreshButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        refreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 680, Short.MAX_VALUE)
                    .addComponent(moviesListLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(225, 225, 225)
                .addComponent(refreshButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(moviesListLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exitButton)
                    .addComponent(refreshButton))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        this.dispose();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        if (this.moviesListLabel.getText().equals("Movies List")) {
            this.getMoviesList();
        } else if (this.moviesListLabel.getText().equals("All Users")) {
            this.getUserList();
        } else if (this.moviesListLabel.getText().equals("Stars List")) {
            this.getStarsList();
        } else {
            errorScreen.sendError("Refresh button does not work for this list.");
        }
    }//GEN-LAST:event_refreshButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton exitButton;
    private javax.swing.JScrollPane jScrollPane1;
    private static javax.swing.JTextArea movieListTextArea;
    private javax.swing.JLabel moviesListLabel;
    private javax.swing.JButton refreshButton;
    // End of variables declaration//GEN-END:variables
}
