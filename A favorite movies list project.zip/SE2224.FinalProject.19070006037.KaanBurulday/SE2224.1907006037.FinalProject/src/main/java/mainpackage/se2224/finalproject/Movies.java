/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainpackage.se2224.finalproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author kaanb
 */
public class Movies {
    private String title;
    private int year;
    private int length;
    private String genre;
    private String studioName;
    private String producerName;
    private String shortDescription;
    private double avgRating;
    private int numWatched;
    public final int movieID;
    public int nextID = 1;
    File moviesFile = new File(FilePaths.movies);
    ErrorScreen errorScreen = new ErrorScreen();
    
    public Movies(String title, int year, int length, String genre, String studioName, String producerName, String shortDescription, double avgRating, int numWatched) {
        this.title = title;
        this.year = year;
        this.length = length;
        this.genre = genre;
        this.studioName = studioName;
        this.producerName = producerName;
        this.shortDescription = shortDescription;
        this.avgRating = avgRating;
        this.numWatched = numWatched;
        this.movieID = getNextID();
    }

    public String getTitle() {
        return title;
    }
    public int getYear() {
        return year;
    }
    public int getLength() {
        return length;
    }
    public String getGenre() {
        return genre;
    }
    public String getStudioName() {
        return studioName;
    }
    public String getProducerName() {
        return producerName;
    }
    public String getShortDescription() {
        return shortDescription;
    }
    public double getAvgRating() {
        return avgRating;
    }
    public int getNumWatched() {
        return numWatched;
    }
    public int getMovieID() {
        return movieID;
    }


    public void setNumWatched(int numWatched) {
        this.numWatched = numWatched;
    }
    public void setAvgRating(double avgRating) {
        this.avgRating = avgRating;
    }
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }
    public void setProducerName(String producerName) {
        this.producerName = producerName;
    }
    public void setStudioName(String studioName) {
        this.studioName = studioName;
    }
    public void setGenre(String genre) {
        this.genre = genre;
    }
    public void setLength(int length) {
        this.length = length;
    }
    public void setYear(int year) {
        this.year = year;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    
    public int getNextID(){
        int id = 0;
        if (moviesFile.length() == 0){ 
            id = nextID;
            nextID++;
            return id;
        } else {
            try {
                BufferedReader breader = new BufferedReader(new FileReader(moviesFile));
                String line = null;
                while ((line = breader.readLine()) != null){
                    String[] movieInfo = line.split(" ");
                    id = Integer.parseInt(movieInfo[0]);
                }
                id++;
            } catch (Exception e){
            errorScreen.sendError("An error occured while calculating the next ID.");
            }
        }
        return id;
    }

    public String getMovieDetails(){
        String str = "";
        str += getMovieID() + " " + getTitle() + " " + getYear() + " " + getGenre() + " " + getLength() + " " + getNumWatched() + " " + getProducerName() + " " + getStudioName() + " " + getAvgRating() + " " + getShortDescription();
        return str;
    }

    public void enterMovieToFile(Movies movie){  
        try {
            BufferedWriter bwriter = new BufferedWriter(new FileWriter(moviesFile, true));
            BufferedReader breader = new BufferedReader(new FileReader(moviesFile));
            if(breader.readLine() != null){
                bwriter.append("\n" + movie.getMovieDetails());
            } else if(breader.readLine() == null){
                bwriter.append(movie.getMovieDetails());
            }
            bwriter.close();
            breader.close();
            errorScreen.sendNotification("Your movie ID is: " + movie.getMovieID());
        } catch (Exception e){
            errorScreen.sendError("An error occured while saving your movie.");
        }
    }

    

}
